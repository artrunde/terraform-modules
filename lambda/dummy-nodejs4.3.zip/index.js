exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Hello world from Lambda!');
};