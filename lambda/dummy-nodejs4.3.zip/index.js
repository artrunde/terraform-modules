exports.handler = (event, context, callback) => {

  var headers = {};

  var response = {
    statusCode: 200,
    headers: headers,
    body: '{"Hello":"World"}'
  };

  context.succeed(response);

};